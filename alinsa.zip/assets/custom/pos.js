// Custom Javascript Code for POS
