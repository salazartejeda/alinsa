<?php

defined('BASEPATH') or exit('No direct script access allowed');

/*
 * última edición: 22/03/2015
 * Ricardo Ramírez R.
 * Adan Rivera - 12/08/2016
 */

$lang['add_biller']                   = 'Agregar Facturador';
$lang['edit_biller']                  = 'Editar Facturador';
$lang['delete_biller']                = 'Eliminar Facturador';
$lang['delete_billers']               = 'Eliminar Facturadores';
$lang['biller_added']                 = 'Facturador agregado exitosamente';
$lang['biller_updated']               = 'Facturador actualizado exitosamente';
$lang['biller_deleted']               = 'Facturador eliminado exitosamente';
$lang['billers_deleted']              = 'Facturadores eliminados exitosamente';
$lang['no_biller_selected']           = 'Ningún facturador seleccionado. Por favor, selecciona al menos un facturador.';
$lang['invoice_footer']               = 'Pie de Página de la Factura';
$lang['biller_x_deleted_have_sales']  = '¡Acción fallida! El facturador tiene ventas';
$lang['billers_x_deleted_have_sales'] = 'Algunos facturadores no pueden ser eliminados ya que tienen ventas';

