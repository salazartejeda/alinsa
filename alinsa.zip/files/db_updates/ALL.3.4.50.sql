UPDATE `sma_settings` SET `version` = '3.4.50' WHERE `setting_id` = 1;
